# Mu 音乐 v1.4 — 第二批：从 MusicFree 借鉴的 4 个交互

> APP：`com.r3zound.music` v1.4.0
> 来源：[maotoumao/MusicFree](https://github.com/maotoumao/MusicFree) 的交互设计
> 第一批见 `v1.3-MusicFree借鉴说明.md`，完整对比见 `MusicFree设计对照分析.md`

---

## 1. 播放历史页（把已经建好却一直没用上的表用起来）

**背景**：`Room` 里其实**早就建好了 `play_history` 表和 `HistoryDao`**，
`AppModule` 也提供了 `provideHistoryDao`，但 UI 一次都没用过——
搜索历史用得好好的，播放历史是空的。

**Mu 音乐 v1.4 的做法**

写入（`PlayerHolder.recordHistory`）：
- 在 `onMediaItemTransition` 里写，也就是**真正切到这首歌时**才记，
  拖进度条不会刷出一堆记录
- 同一首歌重复播放 → `deleteByKey` + `insert`，**更新时间戳而不是插新行**，
  历史里不会连出好几条一样的
- `extraJson` 一并存下来 → 从历史重播时取流照样能带上音质参数
- `trimTo(100)` 自动裁剪，表不会无限增长

读取与展示：
- 收藏页新增第 4 个 tab「**最近播放 N**」
- 每行右侧显示相对时间（刚刚 / 5 分钟前 / 昨天 / 3-12）
- 同样接了「正在播放高亮」和「准星定位按钮」
- 点一行直接播，点歌手名跳搜索页

**顺带修的坑**：从历史恢复曲目时，音质档位会丢（`qualityOptions` 是空的，
音质选择器就没内容了）。原因是 `extra` 里其实**就带着** `qualityOptions`，
只是恢复时没提取。这轮把解析逻辑抽成了公共工具 `core/util/QualityOptions.kt`，
`MusicApi` 和 `FavoriteRepository` 共用同一份实现，顺手消掉了重复代码。

---

## 2. 歌词字号 + 时间偏移校正

**MusicFree 的做法**
`setFontSize.tsx` 调字号，`setLyricOffset.tsx` 调时间偏移，
偏移由 `lyricManager.updateLyricOffset(item, offset)` 管理。

**Mu 音乐 v1.4 的做法**

**字号**（全局，sp）
- 存 DataStore：`lyric_font_size`
- 可调范围 12–24，默认 16
- 当前行比基准大 2sp、下一行大 1sp

**时间偏移**（**按歌曲存**，毫秒）
- 存 DataStore，key = `lyric_offset_<provider>_<id>`
- 范围 ±5000ms，步进 500ms
- 语义：正数 = 歌词提前，负数 = 歌词延后

**生效点**（两处都要算偏移，否则会错位）
```kotlin
// 高亮：歌词实际时间 = 歌词时间 + offset
fun lyricIndexAt(positionMs: Long, offsetMs: Long = 0L): Int

// 点击歌词跳转：同样要加偏移
onLineClick = { entry -> vm.seekTo(entry.timeMs + lyricOffset) }
```

**入口**：歌词页顶部那行（小封面 + 歌名）右边加了个「歌词设置」图标（Tune），
点开是底部面板：**字号**（加减按钮 + 实时预览）+ **时间偏移**（加减按钮 + 重置）。
只有歌词页才有这个入口，不会占用播放页已经很满的快捷键行。

---

## 3. Mini Player 横向滑动切歌

**MusicFree 的做法**（`components/musicBar/musicInfo.tsx`）
用 Pan 手势，**带惯性判定**：
- 位移超过歌曲卡宽度的 30% → 切上一首/下一首
- 或者速度超过 1500 px/s → 也切
- 都不满足 → 带动画回到原位

**Mu 音乐 v1.4 的做法**

`MiniPlayer.kt` 重写：
- `Modifier.pointerInput { detectHorizontalDragGestures(...) }` 接管横向拖动
- `pointerInput` 放在 `clickable` **之后**（更内层）→ 拖动超过阈值会自动取消点击，
  不会误触发「打开播放页」
- 拖动时整个卡片跟着横向位移（`graphicsLayer { translationX }`）
- 判定逻辑与 MusicFree 一致：
  ```kotlin
  val direction = when {
      abs(offsetX.value) > size.width * 0.3f -> if (offsetX.value > 0) -1 else 1
      abs(dragSpeed) > 1.5f -> if (dragSpeed > 0) -1 else 1
      else -> 0
  }
  ```
  （1.5 px/ms ≈ 1500 px/s）
- 松手时：切歌 → 先滑出屏幕 → 换歌 → 新歌从反方向滑入；
  没达到阈值 → `Animatable.animateTo(0f)` 弹回原位

速度是用拖动事件的时间差自己算的（`change.uptimeMillis` 的差分），
没用 `VelocityTracker`，少一个 API 兼容风险。

---

## 4. 分享当前歌曲

**MusicFree 的做法**
播放页右上角一个分享图标，调插件的 `share` 能力生成链接。

**Mu 音乐 v1.4 的做法**
播放页顶栏加了个分享图标（`Icons.Outlined.Share`），调系统分享：

```
《想你就写信 (Live)》 - 周杰伦, 李硕, 张鑫
专辑：中国新歌声第二季 第13期
来自 Mu 音乐
```

- 分享纯文本，**不带任何私有信息**（收藏、播放历史都不外传）
- 用 `Intent.createChooser` 让用户选分享到哪个应用
- 用 `runCatching` 包住 `startActivity`：某些定制系统没有可用的分享目标，
  不至于崩

---

## 附：这一轮的新增文件

| 文件 | 作用 |
|---|---|
| `core/util/QualityOptions.kt` | 音质档位解析（MusicApi 和 FavoriteRepository 共用） |
| `ui/components/LyricSettingsSheet.kt` | 歌词设置面板（字号 + 偏移） |

## 验证情况

| 项 | 结果 |
|---|---|
| `:app:compileDebugKotlin` | 通过（0 error） |
| `:app:assembleRelease` | 通过，APK 已签名 |
| APK | `com.r3zound.music` / v1.4.0 / minSdk 24 / targetSdk 34 |

> 滑动手感、歌词偏移的实际观感**没法在沙箱里验证**，需要你装到真机上试。
> 特别是滑动手感——阈值（30% 宽度 / 1.5 px/ms）和回弹时长都是照着 MusicFree 抄的，
> 但 Android 和 iOS 的手势系统不一样，可能需要微调。

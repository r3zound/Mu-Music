# Mu 音乐 v1.3 — 从 MusicFree 借鉴的 5 个交互

> APP：`com.r3zound.music` v1.3.0
> 来源：[maotoumao/MusicFree](https://github.com/maotoumao/MusicFree) 的交互设计
> 详细对比见 `MusicFree设计对照分析.md`

---

## 1. 列表内「正在播放」高亮

**MusicFree 的做法**（`components/mediaItem/musicItem.tsx`）
列表项接一个 `highlight` 属性，命中当前播放的歌曲时**标题和序号都换成主色**。

**Mu 音乐的做法**
- `TrackRow` 新增 `isPlaying: Boolean` 参数
  - 标题：主色 + `SemiBold` 加粗
  - 歌手：主色
- 接入了三个列表页：**搜索结果**（分组 / 合并两种模式都接了）、
  **收藏页「全部歌曲」**、**歌单详情**
- 数据来源：各 ViewModel 订阅 `PlayerHolder.state`，把当前曲目算成
  `provider:id` 放进 uiState（`currentSongKey`）

**为什么**：在 60 首的搜索结果里点了第 47 首，往下滚之后完全不知道"现在在放哪首"。
这是零成本的信息反馈。

---

## 2. 「正在播放」定位准星按钮

**MusicFree 的做法**（`components/musicList/index.tsx`）
右下角浮一个 crosshair 圆形按钮：滚动时出现、点它滚回当前播放项、滚完 5 秒自动隐藏。

**Mu 音乐的做法**
新增 `ui/components/PlayingLocator.kt`：

```kotlin
PlayingLocator(
    locatable = 当前播放项在列表里,
    listState = listState,
    onLocate = { listState.scrollToItem(index) },
)
```

- 滚动开始 → 显示；停止滚动 5 秒 → 自动隐藏
- 用 `collectLatest`：滚动重新开始会取消上一次等待，不会误隐藏
- 组件是**通用**的：下标算法由调用方给，所以分组模式也能精确定位

**分组模式的下标算法**（`SearchScreen.locateIndex`）比较绕，因为渲染结构是
「分组标题 + 骨架占位 / 空结果提示 / N 首曲目」混在一起：

```kotlin
SearchGroupMode.BY_PROVIDER -> {
    var index = 0
    for (provider in state.activeProviders) {
        index += 1                       // 分组标题
        when {
            result == null -> index += 1 // 骨架占位
            result.items.isEmpty() -> index += 1  // 空结果提示
            else -> {
                val i = result.items.indexOfFirst { ... }
                if (i >= 0) return index + i
                index += result.items.size
            }
        }
    }
    -1
}
```

---

## 3. 歌词点击跳转

**MusicFree 的做法**（`musicDetail/components/content/lyric/index.tsx`）
点任意一行歌词 → `seekTo(该行时间)`，立刻跳过去继续播。

**Mu 音乐的做法**
- `LyricSection` 新增 `onLineClick: ((LyricEntry) -> Unit)?`
- `LyricLine` 加 `onClick`，命中时加一层 `Modifier.clickable`
- 播放页接上：`onLineClick = { entry -> vm.seekTo(entry.timeMs) }`

> 歌词时间在本工程里已经是**毫秒**（`LyricEntry.timeMs`），和进度条单位一致，不用换算。

---

## 4. 播放页模糊封面背景

**MusicFree 的做法**（`musicDetail/components/background.tsx`）
当前封面铺满全屏 + `blurRadius=50` + `opacity=0.5`，底下垫纯黑。

**Mu 音乐的做法**
新增 `BlurredCoverBackground()`：
- 封面 `ContentScale.Crop` 铺满 → `Modifier.blur(70.dp, BlurredEdgeTreatment.Unbounded)` → 黑色遮罩
- **兼容性**：`Modifier.blur` 需要 API 31（Android 12），低版本 Compose 的 blur 是空操作，
  所以低版本改成「封面图 + 更重的黑遮罩（0.74 vs 0.45）」近似，视觉上不会突变

### 顺带解决的坑：浅色主题下文字看不见

背景永远是暗的（封面模糊 + 黑遮罩），所以**播放页强制使用深色配色**，
跟 APP 的浅色/深色主题无关：

```kotlin
val playerScheme = MaterialTheme.colorScheme.copy(
    background = Color.Transparent,
    onBackground = Color.White,
    surface = Color.Transparent,
    onSurface = Color.White,
    onSurfaceVariant = Color.White.copy(alpha = 0.72f),
    surfaceContainerHigh = Color.White.copy(alpha = 0.10f),
)
MaterialTheme(colorScheme = playerScheme) { ... }
```

播放页里原来的 `MuPalette.ink2` / `MuPalette.ink3` 也换成了这套浅色梯度。

---

## 5. 睡眠定时器

**MusicFree 的做法**（`components/panels/types/timingClose.tsx`）
底部弹窗，10 / 20 / 30 / 45 / 60 分钟快捷档，标题显示实时倒计时。

**Mu 音乐的做法**
- `PlayerHolder` 新增定时器（`SleepTimerState` + `startSleepTimer` / `cancelSleepTimer`）
  - 走 `CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)`
  - 每秒更新一次剩余时间，到点 `player.stop()` 并复位
  - 重复调用是**重新计时**而不是累加
- 新增 `ui/components/SleepTimerSheet.kt`（Material3 `ModalBottomSheet`）
  - 快捷档 10/20/30/45/60 分钟 + 「关闭定时」
  - 定时生效时面板标题显示倒计时
- 播放页快捷键行新增第 5 个按钮「定时」
  - 生效时图标变实心、标签变成倒计时（如 `12:34`）、主色高亮
- 快捷键行从 4 个变 5 个，`QuickAction` 的横向内边距从 14dp 收到 9dp，避免拥挤

---

## 附：这一轮的其它改动

- 快捷键行新增「定时」后，`QuickAction` 内边距 14dp → 9dp
- 播放页整体改为固定深色配色（见上面第 4 条）

## 验证情况

| 项 | 结果 |
|---|---|
| `:app:compileDebugKotlin` | 通过（0 error） |
| `:app:assembleRelease` | 通过，APK 已签名 |
| APK | `com.r3zound.music` / v1.3.0 |

> 交互效果（准星按钮的出现时机、模糊背景的观感、倒计时）**没法在沙箱里验证**，
> 需要你装到真机上确认。

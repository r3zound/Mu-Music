# Mu 音乐 v1.5 — 导航结构与渠道自动勾选重构

> APP：`com.r3zound.music` v1.5.0
> 本轮是结构性重构，不是加功能。

---

## 一、底栏从 5 项变 4 项

| 旧 | 新 |
|---|---|
| 首页 / 搜索 / 收藏 / 下载 / 设置 | **首页 / 播放列表 / 收藏 / 设置** |

- **搜索** → 合并进首页，成为首页的一个子版块
- **下载** → 合并进设置，从设置页「下载管理」区块进入

---

## 二、首页变成「发现 / 搜索」双子版块

```
首页
├── 发现   快捷入口 + 13→9 个分类 + 最近搜索
└── 搜索   搜索框 + 搜索历史 + 结果区
```

### 为什么搜索不能再是独立路由

搜索现在是首页的一个 tab，那「点歌手名」「点分类」这些跨页面入口怎么触发它？

如果用路由参数传（`home?keyword=xxx`），Navigation 会把它当成**另一个 destination** →
新的 back stack entry → **新的 ViewModel 实例** → 搜索结果的上下文被切断
（用户在别的页面点歌手，页面直接跳到一个孤立的搜索页，底栏什么都不高亮）。

所以改用 `SearchNavState`（`@Singleton`）做中转：

```kotlin
// 任何页面
searchNavState.request(artist)
navController.navigate(Routes.HOME)

// 首页（一直活着）
LaunchedEffect(Unit) {
    searchNavState.request.collect { req: SearchRequest? ->
        if (req != null) {
            tab = HomeTab.SEARCH
            searchViewModel.searchWithProviders(req.keyword, req.providers)
            searchNavState.consume()
        }
    }
}
```

`SearchNavState` 是 `@Singleton` 而 `hiltViewModel()` 只能取 `@HiltViewModel`，
所以用 Hilt 的 **EntryPoint** 方式从 Application 取（`ui/nav/SearchNav.kt`）。

---

## 三、新增「播放列表」页（底栏第 2 项）

```
播放列表
├── 我的歌单 N    歌单网格，新建/重命名/改描述/删除
└── 最近播放 N    播放历史（相对时间）
```

**「历史播放歌曲等菜单」的需求落在这一页。**

顺带把**「把当前播放队列存成歌单」**做上了：
播放队列页顶栏 → 「存为歌单」→ 填名字 → 当前队列整队存成新歌单。

原来的「我的歌单 / 最近播放」从收藏页搬到这里，收藏页收窄为「全部歌曲 / 标签」——
每个功能只有一个归属，不重复。

---

## 四、渠道选择：体检结果自动勾选

### 之前

搜索页顶部有一排渠道 chip（17 个），用户手动勾选。上面还有「筛选」和「设置」两个按钮。

### 现在

1. **搜索页的渠道 chip 行整个删掉**，顶栏的齿轮（设置）和漏斗（筛选）也删掉
2. 渠道勾选移到 **设置 → 渠道体检**
3. **体检完自动勾选**：能搜 + 能取流的渠道（`ChannelHealth.OK`）自动勾上，
   不可用的自动排除，用户不用手动挑

### 数据流

```
体检（MusicRepository.checkChannels）
   └─ applyHealthResult(infos)
        ├─ SettingsStore.setEnabledProviders(可用渠道)
        └─ SettingsStore.setLastHealthCheck(now)
                    ↓
        SettingsStore.activeProviders: Flow<Set<String>?>
                    ↓
        SearchViewModel → uiState.selectedProviders → 搜索时用的渠道
```

`activeProviders` 返回 `null` 表示**还没体检过**（此时用注册表全集），
非 null 才是体检结果——这样「所有渠道都不可用」和「没体检」能区分开。

### 体检页现在长这样

- 每行渠道右边有**勾选框**，体检通过的自动勾上
- 不可用的渠道勾选框**禁用**（勾了也搜不出能播的歌）
- 可以**手动取消**某个可用渠道——这是必要的逃生舱（某个渠道偶发抽风时能先摘掉）
- 概览卡片显示「已勾选 N 个渠道参与搜索」

### 一个容易踩的坑

搜索页的 ViewModel 原本在 `init` 里自动跑体检。如果不改，用户在体检页手动取消的渠道
**每次进搜索页都会被覆盖回去**。所以改成：**只有「从未体检过」时才自动跑一次**，
之后都由用户自己在设置里点体检。

---

## 五、分类搜索不改全局勾选

首页点「华语」分类，搜索时用的是该分类指定的渠道，
但**不能**把它写进全局的 `selectedProviders`——否则：

- 用户在体检页手动取消的渠道会被分类覆盖
- 点一次分类，后续所有普通搜索都只剩分类的那几个渠道

所以加了一个临时字段：

```kotlin
/** 本次搜索临时指定的渠道（首页分类用），搜完就清空。 */
val searchProviders: Set<String> = emptySet()

val activeProviders: List<String>
    get() = ProviderRegistry.all.map { it.id }
        .filter { it in (searchProviders.ifEmpty { selectedProviders }) }
```

发起搜索后立刻 `searchProviders = emptySet()`，临时渠道只对这一次生效。

---

## 六、其它

- 首页顶栏的齿轮按钮移除（现在有 tab 行了）
- 首页快捷入口第三个从「下载管理」改成「**播放列表**」（下载在设置里）
- 设置页新增「下载管理」区块入口，原来的下载偏好归到「下载偏好」

---

## 七、验证

| 项 | 结果 |
|---|---|
| `:app:compileDebugKotlin` | 通过（0 error） |
| `:app:assembleRelease` | 通过，APK 已签名 |
| APK | `com.r3zound.music` / v1.5.0 / minSdk 24 / targetSdk 34 |

> 交互（首页 tab 切换、跨页面跳转后自动搜、准星定位在首页搜索 tab 里是否正常）
> **没法在沙箱里验证**，需要你装真机确认。
